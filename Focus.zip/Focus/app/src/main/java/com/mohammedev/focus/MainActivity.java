package com.mohammedev.focus;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    private static final String SEND_DATA = "DATE_TIME";
    TextView timerTxt;
    TextView fullTime;
    Button pause;
    Button start;
    Button history;
    Button stop;
    Timer timer;
    TimerTask timerTask;
    double time = 0.0;
    double fullTimeDouble = 0.0;

    boolean timerStart = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timerTxt = findViewById(R.id.timer_txt);
        pause = findViewById(R.id.pause_btn);
        start = findViewById(R.id.start_btn);
        history = findViewById(R.id.history_btn);
        stop = findViewById(R.id.stop_btn);
        fullTime = findViewById(R.id.hide_full_txt);
        fullTime.setVisibility(View.INVISIBLE);
        if (!timerStart){
            pause.setEnabled(false);
            stop.setEnabled(false);
        }
    timer = new Timer();
    }

    public void startButton(View view){
        if (!timerStart){
            timerStart = true;
            start.setEnabled(false);
            pause.setEnabled(true);
            stop.setEnabled(true);
            startTimer();
        }

    }

    public void pauseButton(View view){
        if (timerStart){
            timerStart = false;
            pause.setEnabled(false);
            start.setEnabled(true);
            timerTask.cancel();
        }

    }

    public void stopButton(View view){
            stop.setEnabled(false);
            String stoppedTime = (String) fullTime.getText();

        Toast.makeText(this,stoppedTime , Toast.LENGTH_SHORT).show();
        if (stoppedTime != null){
            SharedPreferences mySharedPreferences = this.getSharedPreferences(SEND_DATA, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = mySharedPreferences.edit();
            editor.putString("date",getDate());
            editor.putString("stoppedTime",stoppedTime);
            editor.apply();
        }


        if (timerStart){
            start.setEnabled(true);
            pause.setEnabled(false);
            timerTask.cancel();
            time = 0.0;
            fullTimeDouble = 0.0;
            fullTime.setText(formatTimeSeconds(0 , 0));
            timerTxt.setText(formatTimeSeconds(0 , 0));
            timerStart = false;
        } else {
            time = 0.0;
            fullTimeDouble = 0.0;
            fullTime.setText(formatTimeSeconds(0 , 0));
            timerTxt.setText(formatTimeSeconds(0 , 0));
        }

    }

    public void historyButton(View view){
        Intent intent = new Intent(MainActivity.this , HistoryActivity.class);
        startActivity(intent);
    }

    private void startTimer()
    {
        timerTask = new TimerTask()
        {
            @Override
            public void run()
            {
                runOnUiThread(new Runnable()
                {
                    @Override
                    public void run()
                    {

                        if (time >= 59.0){
                            time++;
                            fullTimeDouble++;
                            timerTxt.setText(getTimerTextMinutes());
                            fullTime.setText(getTimerTextSeconds());
                        } else{
                            time++;
                            fullTimeDouble++;
                            fullTime.setText(getTimerTextSeconds());
                            timerTxt.setText(getTimerTextSeconds());
                        }
                    }
                });
            }

        };
        timer.scheduleAtFixedRate(timerTask, 0 ,1000);
    }


    public String getTimerTextSeconds(){
        int rounded = (int) Math.round(time);
        int seconds = ((rounded % 86400)% 3600) % 60;
        int minutes = ((rounded % 86400)% 3600) / 60;

        return formatTimeSeconds(seconds , minutes);
    }

    public String getTimerTextMinutes(){
        int rounded = (int) Math.round(time);
        int minutes = ((rounded % 86400)% 3600) / 60;

        return formatTimeMinutes(minutes);
    }

    public String formatTimeSeconds(int seconds , int minutes){
        return String.format("%02d",minutes) + ":" + String.format("%02d", seconds);
    }

    public String formatTimeMinutes(int minutes){
        return String.format("%02d",minutes);
    }

    public String getDate(){
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
        String formattedDate = df.format(c);
        return formattedDate;
    }
}