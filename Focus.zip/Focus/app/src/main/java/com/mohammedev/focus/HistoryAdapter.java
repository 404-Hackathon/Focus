package com.mohammedev.focus;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter {

    Context mContext;
    ArrayList<HistoryDetails> historyDetails;

    public HistoryAdapter(Context mContext, ArrayList<HistoryDetails> historyDetails) {
        this.mContext = mContext;
        this.historyDetails = historyDetails;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.history_layout , parent , false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        ((ViewHolder)holder).date.setText(historyDetails.get(position).getDate());
        ((ViewHolder)holder).stoppedTime.setText(historyDetails.get(position).getTimeCounted());
    }


    @Override
    public int getItemCount() {
        return historyDetails.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView date;
        TextView stoppedTime;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.date_txt);
            stoppedTime = itemView.findViewById(R.id.time_counted_txt);
        }
    }
}
