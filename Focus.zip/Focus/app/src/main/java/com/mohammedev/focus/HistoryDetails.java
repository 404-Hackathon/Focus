package com.mohammedev.focus;

import androidx.recyclerview.widget.RecyclerView;

public class HistoryDetails {
    private String date;
    private String timeCounted;


    public HistoryDetails(String date, String timeCounted) {
        this.date = date;
        this.timeCounted = timeCounted;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTimeCounted() {
        return timeCounted;
    }

    public void setTimeCounted(String timeCounted) {
        this.timeCounted = timeCounted;
    }
}
