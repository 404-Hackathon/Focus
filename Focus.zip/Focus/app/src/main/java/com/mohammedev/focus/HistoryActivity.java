package com.mohammedev.focus;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {
    private static final String SEND_DATA = "DATE_TIME";
    private static final String SAVED_DATA = "SAVED_DATA";

    ArrayList<HistoryDetails> historyList = new ArrayList<>();
    Button saveData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        saveData = findViewById(R.id.save_data_btn);

        saveData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  saveData();
            }
        });

        HistoryAdapter historyAdapter = new HistoryAdapter(this ,historyList);
        recyclerView.setAdapter(historyAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //loadData();

        SharedPreferences mySharedPreferences = this.getSharedPreferences(SEND_DATA, Context.MODE_PRIVATE);
        String date = mySharedPreferences.getString("date", "");
        String stoppedTime = mySharedPreferences.getString("stoppedTime" , "");



        historyList.add(new HistoryDetails(date , stoppedTime));



    }


//    public void loadData(){
//        SharedPreferences savedSharedPreferences = this.getSharedPreferences(SAVED_DATA , MODE_PRIVATE);
//        Gson gson = new Gson();
//        String json = savedSharedPreferences.getString("historyList","");
//        Type type = new TypeToken<ArrayList<HistoryDetails>>() {}.getType();
//        historyList = gson.fromJson(json,type);
//
//        if (historyList == null){
//            historyList = new ArrayList<>();
//        }
//
//    }

//        public void saveData(){
//            SharedPreferences savedSharedPreferences = this.getSharedPreferences(SAVED_DATA , MODE_PRIVATE);
//            SharedPreferences.Editor editor = savedSharedPreferences.edit();
//            Gson gson = new Gson();
//            String json = gson.toJson(historyList);
//            editor.putString("historyList", json);
//            editor.apply();
//    }
}